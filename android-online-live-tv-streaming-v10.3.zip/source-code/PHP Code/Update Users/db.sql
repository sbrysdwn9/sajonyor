ALTER TABLE `tbl_settings` 
ADD `site_direction` varchar(200) NOT NULL DEFAULT '0';